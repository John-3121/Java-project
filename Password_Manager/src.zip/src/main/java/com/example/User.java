import java.util.*;

public class User{
    ArrayList<Sites> entries = new ArrayList<Sites>();
    Scanner sn = new Scanner(System.in);
      //Database db = new Database();
    private String Username;
    private String Password;
      private String Line;
      
      public ArrayList<Sites> Slist(){
            return entries;
      }
    public void entries(){
          System.out.println("Enter site name");
          String site = sn.nextLine();
          System.out.println("Enter your username");
          String uname = sn.nextLine();
          System.out.println("Enter your password");
          String passwd = sn.nextLine();
          System.out.println(entries);
          
          entries.add(new Sites(site,uname,passwd));
    }
      User(String Line){
            this.Line=Line;
      }
    User(String Username,String Password){
        this.Username = Username;
        this.Password = Password;
    }
    User(){}
    public String getUser(){return Username;}
    public String getPass(){return Password;}
    
        
    @Override
    public String toString() {
        return Username + "," + Password;
    }
      
      public User splitData(String line){
            String[] data =line.split(",");
            return new User(data[0],data[1]);
      }
        
    }
    
    
    
    
