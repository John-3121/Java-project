import java.io.*;
import java.util.*;
public class Database{
    File file_path = new File("/storage/emulated/0/Password_Manager/src/main/java/com/example/Users.txt");
    ArrayList<User> users = new ArrayList<User>();
    Scanner sn =new Scanner(System.in);
    Main m= new Main();
    Sites sie =new Sites();//site==> sie
    User user = new User();
    User currentuser;
    File file_path1;
    public ArrayList<User> ulist(){
        return users;
    }
    
    
    public void Signup(){
          System.out.println("Enter your username");
          String uname = sn.nextLine();
          System.out.println("Enter your password");
          String passwd = sn.nextLine();
      if(uname.contains(",") || passwd.contains(",")){
          System.out.println("error");
      }else if(uname.contains(" ") || passwd.contains(" ")){
          System.out.println("Username or password cannot contain a space");
      }
        else if (uname==""||passwd==""){
            System.out.println("Username or password cannot be 'none' or 'empty'.");
        }
          else{
          users.add(new User(uname,passwd));
          System.out.println(users);
          saveUser();
              
      }
          
    }
    
    public User Signin(){
            System.out.println("-----------");
            System.out.print("Enter your username: ");
            String uname= sn.nextLine();
            System.out.println("-----------");
            System.out.print("Enter your password: ");
            String passwd = sn.nextLine();
            System.out.println("-----------");
        
        for(User us:users){//user ==> us
            if (uname.equals(us.getUser()) && passwd.equals(us.getPass())){
                System.out.println("Account login successfully");
                currentuser = us;
                file_path1 = new File("/storage/emulated/0/Password_Manager/src/main/java/com/UsersData/"+currentuser.getUser()+".txt");
                try{
                    if(!file_path1.exists()){
                       FileWriter fileWriter = new FileWriter(file_path1);
                      //this will check if the file exist then not create it
                      //if we did not create it before it logins it gomna throw an error  
                    }
                }catch(IOException e){
                    e.printStackTrace();
                }
                
                loadSites();
                run();
                return us;
                 }
        }
        System.out.println("Login failed. Check your details and try again.");
        m.Main_menu();
        return null;
        
    }

    public void run(){
        boolean running = true;
        while(running){
            //  System.out.println(currentuser);
        System.out.println("-----------");
        System.out.println("Select an option");
        System.out.println("1.Add entrie");
        System.out.println("2.View all passwords");
        System.out.println("3.remove Site");
        System.out.println("4.Logout");
        try{
            int input = sn.nextInt();
            if(input==1){
                user.entries();
                saveSites();
            }else if(input ==2){
                view_all_passwords();
            }else if(input ==3){
                remove_Site();
            }else if(input ==4){
                running=false;
                Logout();
            }
        }catch(InputMismatchException e){
            System.out.println("invalid input");
            Signin();
        }
        }
      
    }
    
    public void view_all_passwords(){
        ArrayList<Sites> i = user.Slist();
        int z=0;
        for(Sites y:i){
            System.out.println((z+=1)+":"+ y.view_pass());
            System.out.println("------------------");
        }
       
        
        
    }
    public void remove_Site(){
        System.out.println("Enter a site u want to remove");
        int input = sn.nextInt();
        ArrayList<Sites> site= currentuser.Slist();
        site.remove(input-1);
        
        
    }
    public void Logout(){
        user.entries.clear();
      // users.clear();
        users.remove(currentuser);
        System.out.println(users);
        currentuser=null;
        m.Main_menu();
        
    }
   public void loadUser(){
        try{
          //  String text = "";
            BufferedReader br = new BufferedReader(new FileReader(file_path));
            String line;
            while((line = br.readLine()) != null){
               users.add(user.splitData(line));
                
            }
            br.close();
            
        }catch(IOException e){
            e.printStackTrace();
        }
        
}
   
    public void saveUser(){
        try{
           BufferedWriter bw = new BufferedWriter(new FileWriter(file_path));
            for(User u:users) {
                bw.write(u.toString());
                bw.newLine();
                
                
            } 
            bw.close();
            
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    
    public void loadSites(){
        try{
            BufferedReader br = new BufferedReader(new FileReader(file_path1));
            String users_data_entries;
            ArrayList<Sites> st= user.Slist();
            while((users_data_entries= br.readLine()) != null){
            st.add(sie.split_user_data(users_data_entries));
        }
            br.close();
        }catch(IOException e){
            e.printStackTrace();
        }
        
        
    }
    
    public void saveSites(){
        try{
            ArrayList<Sites> entries= user.Slist();
           BufferedWriter bw = new BufferedWriter(new FileWriter(file_path1,false));
            for(Sites en:entries){
                bw.write(en.toString());
                bw.newLine();
            } 
            bw.close();
            
        }catch(IOException e){
            e.printStackTrace();
        }
    }}
    
  