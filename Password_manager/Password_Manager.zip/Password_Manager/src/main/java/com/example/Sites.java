
public class Sites {
    String site_name;
    String site_uname;
    String site_passwd;
    
   public Sites(String site_name,String site_uname,String site_passwd){
       this.site_name = site_name;
       this.site_uname = site_uname;
       this.site_passwd = site_passwd;
   }
   public Sites(){}
    public String get_Site_Name(){
        return site_name;
    }
    public String get_Site_Uname(){
        return site_uname;
    }
    public String get_Site_Passwd(){
        return site_passwd;
    }
    
    
    @Override
    public String toString(){
        return "Site:" + this.get_Site_Name()+","+ "Username:" + this.get_Site_Uname() + ","+ "Password:" + this.get_Site_Passwd();
        
    }
    public String view_pass(){
        return "Site:" + this.get_Site_Name()+"\n"+ "Username:" + this.get_Site_Uname()+"\n"+ "Password:" + this.get_Site_Passwd();
     //this is used to view the passwords instead of using the toString
//cause if i use that its more complicated to fixed 
//so i just make a new method to just view the entries     
    }
    /*
    public Sites split_user_data(String data){
        String[] entry = data.split(",");
        return new Sites(entry[0],entry[1],entry[2]);
    }*/
    public Sites split_user_data(String data){
    String[] entry = data.split(",");
    // Remove the labels before creating the Sites object
    //So when you view the entries the labes wont get doubled    
    String siteName = entry[0].replace("Site:", "");
    String username = entry[1].replace("Username:", "");
    String password = entry[2].replace("Password:", "");
    return new Sites(siteName, username, password);
}
}