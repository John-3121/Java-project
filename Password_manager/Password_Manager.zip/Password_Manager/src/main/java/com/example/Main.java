import java.util.*;
import java.io.*;

public class Main {
   static Main m= new Main();
   static Database db = new Database();
    public static void main(String[] args) {
    // db.loadUser();
      m.Main_menu();
      
}
    public void Main_menu(){
      db.loadUser();
      Scanner sn = new Scanner(System.in);
      /*
        UserManager um = new UserManager();
        User u =new User();
        List<User> d = um.list();
        UserManager user =  um.storeUser("kwen","kaw lang");
        UserManager user2 =  um.storeUser("carlo","hi");
        System.out.println(um.list());
        */
      
        System.out.println("-------------");
        System.out.println("Select an option\n1.Sign up\n2.Sign in\n----------");
        try{
            int uinput = sn.nextInt();
            
         if(uinput <= 0||uinput >2){
            Main_menu();
         }
            if(uinput ==1){
              db.Signup();
              Main_menu();
            }else if(uinput ==2){
               db.Signin();
               }
          
        }catch(InputMismatchException e){
            System.out.println("Invalid input");
            Main_menu();
            
            
        }
        
    }
    
}