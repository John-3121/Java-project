/*import java.util.*;


public class UserManager{
    User u=new User();
    List<User> user = new ArrayList<User>();
    public List<User> list(){
        return user;
    }
    
    public UserManager storeUser(String Password,String Username){
        user.add(new User(Password,Username));
        return this;
    }
    
    
}*/